
const managerConfig = {
    DATA_CDN: '',
    preloadDataList: [
        // 'DATA_CDN/StreamingAssets/WebGL/textures_005b9e6b32e22099edc38cba5b3d11de',
        // '/WebGL/bundles_e1af572c458eda6944e73db25cae88d5',
       
    ],
};
GameGlobal.managerConfig = managerConfig;


const unityNamespace = {
    bootConfig: "player-connection-ip=192.168.180.55"
};

GameGlobal.unityNamespace = GameGlobal.unityNamespace || unityNamespace;

